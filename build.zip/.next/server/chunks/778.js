"use strict";
exports.id = 778;
exports.ids = [778];
exports.modules = {

/***/ 7260:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Box": () => (/* binding */ Box),
/* harmony export */   "Flex": () => (/* binding */ Flex),
/* harmony export */   "HStack": () => (/* binding */ HStack),
/* harmony export */   "SimpleGrid": () => (/* binding */ SimpleGrid),
/* harmony export */   "Stack": () => (/* binding */ Stack),
/* harmony export */   "VStack": () => (/* binding */ VStack)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5024);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(476);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7261);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3206);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7806);
/* __next_internal_client_entry_do_not_use__ Stack,Flex,Box,SimpleGrid,HStack,VStack auto */ 

function Stack(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__/* .Stack */ .K, {
        ...props,
        children: props.children
    });
}
function Flex(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__/* .Flex */ .k, {
        ...props,
        children: props.children
    });
}
function Box(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_3__/* .Box */ .xu, {
        ...props,
        children: props.children
    });
}
function SimpleGrid(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__/* .SimpleGrid */ .M, {
        ...props,
        children: props.children
    });
}
function HStack(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_5__/* .HStack */ .U, {
        ...props,
        children: props.children
    });
}
function VStack(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_6__/* .VStack */ .g, {
        ...props,
        children: props.children
    });
}


/***/ }),

/***/ 3667:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Heading": () => (/* binding */ Heading),
/* harmony export */   "Link": () => (/* binding */ Link),
/* harmony export */   "Text": () => (/* binding */ Text)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5064);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(834);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4141);
/* __next_internal_client_entry_do_not_use__ Heading,Text,Link auto */ 

function Heading(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__/* .Heading */ .X, {
        ...props,
        children: props.children
    });
}
function Text(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__/* .Text */ .x, {
        ...props,
        children: props.children
    });
}
function Link(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_3__/* .Link */ .r, {
        ...props,
        children: props.children
    });
}


/***/ }),

/***/ 2625:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Rating)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(476);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7261);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5484);
/* __next_internal_client_entry_do_not_use__ default auto */ 


function Rating({ rating , numReviews  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__/* .Flex */ .k, {
        align: "baseline",
        children: [
            Array(8).fill("").map((_, i)=>{
                const roundedRating = Math.round(rating * 2) / 2;
                if (roundedRating - i >= 1) {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__/* .BsStarFill */ .kRm, {
                        style: {
                            marginLeft: "1"
                        },
                        color: i < rating ? "teal.500" : "gray.300"
                    }, i);
                }
                if (roundedRating - i === 0.5) {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__/* .BsStarHalf */ .fXH, {
                        style: {
                            marginLeft: "1"
                        }
                    }, i);
                }
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__/* .BsStar */ .RrZ, {
                    style: {
                        marginLeft: "1"
                    }
                }, i);
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_3__/* .Box */ .xu, {
                as: "span",
                ml: "2",
                color: "gray.600",
                fontSize: "sm",
                children: [
                    numReviews,
                    " review",
                    numReviews > 1 && "s"
                ]
            })
        ]
    });
}


/***/ }),

/***/ 3636:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Kq": () => (/* binding */ e0),
/* harmony export */   "MI": () => (/* binding */ e3),
/* harmony export */   "Ug": () => (/* binding */ e4)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof, Flex, Box, VStack */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5985);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\Abdullah Zaydi\Documents\GitHub\SampleNext\components\CoreChakra\Structure.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = (proxy.default);

const e0 = proxy["Stack"];

const e1 = proxy["Flex"];

const e2 = proxy["Box"];

const e3 = proxy["SimpleGrid"];

const e4 = proxy["HStack"];

const e5 = proxy["VStack"];


/***/ }),

/***/ 678:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X6": () => (/* binding */ e0),
/* harmony export */   "rU": () => (/* binding */ e2),
/* harmony export */   "xv": () => (/* binding */ e1)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5985);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\Abdullah Zaydi\Documents\GitHub\SampleNext\components\CoreChakra\Typography.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = (proxy.default);

const e0 = proxy["Heading"];

const e1 = proxy["Text"];

const e2 = proxy["Link"];


/***/ }),

/***/ 789:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HT": () => (/* binding */ GET)
/* harmony export */ });
/* unused harmony exports POST, PUT, DELETE, GETFile */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6502);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const POST = async (url, data = {}, headers = {})=>{
    try {
        const res = await axios.post(`${process.env.BASE_URL}${url}`, data, {
            headers,
            validateStatus: (status)=>{
                // console.log(status);
                return status >= 200;
            }
        });
        return res.data;
    } catch (error) {
        // console.log(error);
        return error;
    }
};
const PUT = async (url, data = {}, headers = {})=>{
    try {
        const res = await axios.put(`${process.env.BASE_URL}${url}`, data, {
            headers,
            validateStatus: (status)=>{
                // console.log(status);
                return status >= 200;
            }
        });
        return res.data;
    } catch (error) {
        // console.log(error);
        return error;
    }
};
const GET = async (url, headers = {})=>{
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${process.env.BASE_URL}${url}?api_key=${process.env.API_KEY}`, {
            headers,
            validateStatus: (status)=>{
                // console.log(status);
                return status >= 200;
            }
        });
        return res.data;
    } catch (error) {
        return error;
    }
};
const DELETE = async (url, data = {}, headers = {})=>{
    try {
        const res = await axios.delete(`${process.env.BASE_URL}${url}`, {
            headers,
            data,
            validateStatus: (status)=>{
                // console.log(status);
                return status >= 200;
            }
        });
        return res.data;
    } catch (error) {
        // console.log(error);
        return error;
    }
};
const GETFile = async (url)=>{
    try {
        const response = await axios.get(url, {
            responseType: "blob"
        });
        return new File([
            response.data
        ], url.split("/")[url.split("/").length - 1], {
            type: response.data.type
        });
    } catch (error) {
        return new File([], error.message);
    }
};


/***/ })

};
;